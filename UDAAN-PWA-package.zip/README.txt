# UDAAN – Daily Goal Tracker (PWA package)

## Files to upload to the existing GitHub repository root
- `index.html` (replace the current file after keeping a backup)
- `manifest.json`
- `service-worker.js`
- `robots.txt`
- `sitemap.xml`
- `icons/icon-192.png`
- `icons/icon-512.png`

Keep the `icons` folder structure exactly as shown. Commit the changes to the `main` branch. GitHub Pages should then serve the PWA files from the same `/daily-goal-tracker/` path.

## Notes
- PWA offline caching works after the app has loaded online at least once.
- Existing goals and reminder preferences remain in browser localStorage; they are not synced between devices.
- The current reminder timer still requires the app page to be open. A service worker alone cannot schedule reliable background reminders; that requires a push-notification service.
- Google indexing is not guaranteed or immediate. Submit `https://mahfoojalam394.github.io/daily-goal-tracker/sitemap.xml` in Google Search Console after uploading.
